// 云函数入口文件

const cloud = require('wx-server-sdk')
const tencentcloud = require("tencentcloud-sdk-nodejs");
cloud.init({
})
var voice = function (Text) {

  const AaiClient = tencentcloud.aai.v20180522.Client;
  const models = tencentcloud.aai.v20180522.Models;

  const Credential = tencentcloud.common.Credential;
  const ClientProfile = tencentcloud.common.ClientProfile;
  const HttpProfile = tencentcloud.common.HttpProfile;

  let cred = new Credential("AKIDs23zkJeiYCblfKjwvgFguxmLlvtcQgqk", "zveDXeZKsBG7nESRBh3DH8nrhJuU3Vjj");
  let httpProfile = new HttpProfile();
  httpProfile.endpoint = "aai.tencentcloudapi.com";
  let clientProfile = new ClientProfile();
  clientProfile.httpProfile = httpProfile;
  let client = new AaiClient(cred, "ap-beijing", clientProfile);

  let req = new models.TextToVoiceRequest();

  let params = '{"Text":"我是","SessionId":"session-1234","ModelType":1}'
  req.from_json_string(params);


  client.TextToVoice(req, function (errMsg, response) {

    if (errMsg) {
      console.log(errMsg);
      return;
    }

    console.log(response.to_json_string());
  });
}
voice();
// 云函数入口函数



  exports.main = async (event, context) => {
    const data = event
    datas = await voice(你好) //调用异步函数，向腾讯云API发起请求
    return datas
  
  }


  
  