// src/index.js

//获取应用实例
const app = getApp();
const Global = app.Globals, GlobalConfig = app.GlobalConfig;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Resource: GlobalConfig.Resource,
    HotThemeList: {
      background:'', list: [{
        "id": 1,
        "title": "我要表白",
        "isHot": 1,
        "sort": 1
      },{
          "id": 2,
          "title": "我要吟诗",
          "isHot": 1,
          "sort": 2
      },{
          "id": 3,
          "title": "我要吐槽",
          "isHot": 1,
          "sort": 2
      },{
          "id": 4,
          "title": "节日祝福",
          "isHot": 1,
          "sort": 2
      }]}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _self = this
    // 处理数据
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var _self = this
  },
})