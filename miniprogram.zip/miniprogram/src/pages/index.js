// src/pages/index.js

//获取应用实例
const app = getApp();
const Global = app.Globals, GlobalConfig = app.GlobalConfig;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    Resource: GlobalConfig.Resource,
    Audio: { status: true },
    UserInfo: {},
    Params:{},
    ThemeByList:{},
    Record: {},
    PlayAudio: {},
    PlayAudioAction: { method: 'pause' },
    bgPlayAudioAction: { method: 'pause' },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _self = this
    _self.audioCtx = wx.createAudioContext('testHearMusic')
    _self.bgHearAudio = wx.createAudioContext('bgHearAudio')
    _self.setData({ Params: { themeId: parseInt(options.id), textIndex:1, pageNum: 1, pageSize:20} })
    GlobalConfig.setUserLogin(function (res) {
      _self.setData({ UserInfo: res})
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (options) {
    var _self = this, params = _self.data.Params
    _self.getRandomTextByTheme(params);
  },
  onHide() { var _self = this; _self.setData({ PlayAudioAction: { method: 'pause' } });},
  onUnload() { var _self = this; _self.setData({ PlayAudioAction: { method: 'pause' } });},
  getRandomTextByTheme(params){
    var _self = this
    result.forEach(function (d,f) {
      if (d.theme.id == params.themeId){
        d.theme.textlist = d.theme.textContent.split('|');
        d.list.map(function (k, i){
          d.list[i].filterT = ' (' + _self.filterVoice(k.filter) + ')'
        })
        _self.setData({ ThemeByList: d});
        console.log(d, f);
      }
    })
  },
  /**
   * 类型
   */
  filterVoice(T){
    let Type = "";
    switch (T){
      case 0: return ""; case 1: return "";case 2: return ""; case 3: return "";
      case 4: return "";case 5: return "";default: return "";
    };
  },
  /**
   * 点击播放试听
   */
  PlayAudio(e){
    var _self = this, Key = e.currentTarget.dataset.key, ThemeByList = _self.data.ThemeByList;
    if (ThemeByList.list[Key].play && ThemeByList.list[Key].play == "play"){
      ThemeByList.list[Key].play = "pause"
      Music(ThemeByList.list[Key]);
    }else{
      ThemeByList.list.map(function(k,i){
        if (k.id == ThemeByList.list[Key].id){
          ThemeByList.list[i].play = "play"
          Music(ThemeByList.list[Key]);
        }else{
          ThemeByList.list[i].play = "pause"
        }
      })
    }
    _self.setData({ ThemeByList: ThemeByList});
    function Music(audio){
      let bgAudioUrl = "";
      _self.setData({ PlayAudioAction: { method: 'pause' }, bgPlayAudioAction: { method: 'pause' }}); 
      if (audio.themeBackgroundMusicUrl) { bgAudioUrl = _self.data.Resource + audio.themeBackgroundMusicUrl}
      var PlayAudio = { recordUrl: _self.data.Resource + audio.recordUrl, bgAudioUrl: bgAudioUrl}
      _self.setData({ PlayAudio: PlayAudio}); 
      if (audio.play == "play"){
        _self.audioCtx.pause(); _self.bgHearAudio.pause();
        _self.setData({ PlayAudioAction: { method: 'play' }, bgPlayAudioAction: { method: 'play' } });
        _self.recordPlayCount(audio);
      }else{
        _self.audioCtx.pause(); _self.bgHearAudio.pause();
      }
    };
  },
  /**
   * 试听结束
   */
  endPlayAudio(){
    var _self = this,ThemeByList = _self.data.ThemeByList;
    ThemeByList.list.map(function (k, i) {
      ThemeByList.list[i].play = "pause"
    })
    _self.audioCtx.pause(); _self.bgHearAudio.pause();
    _self.setData({ ThemeByList: ThemeByList });
  },
  /**
   * 记录用户播放录音
   */
  recordPlayCount(audio){
    var _self = this,ThemeByList = _self.data.ThemeByList;
    ThemeByList.list.map(function (k, i) { if (k.id == audio.id) { ThemeByList.list[i].playCount++ } })
    _self.setData({ ThemeByList: ThemeByList });
  },
  /**
   * 试听播放时长控制内容
   */
  playDurationCtr(audio){
    var _self = this;
    // console.log(parseInt(audio.detail.currentTime));
  },
  /**
   * 换一换事件
   */
  exchangeOnce(e){
    var _self = this, params = _self.data.Params
    params.themeId = Math.round(Math.random() * (result.length - 1))
    _self.getRandomTextByTheme(params);
  },
  /**
   * 加载更多
   */
  MyRecordScroll(e) {
    var _self = this, params = _self.data.Params;
    if (params.pageNum < params.totalPage) {
      params.pageNum++;
      let ThemeByList = _self.data.ThemeByList;
      params.themeTextId = ThemeByList.entity.id

      var MyRecordList = res.result; //更多数据

      let resourceList = ThemeByList.list.reverse();
      resourceList.map(function (k, j) {
        MyRecordList.page.list.unshift(k);
      }); ThemeByList.list = MyRecordList.page
      ThemeByList.list.map(function (k, i) {
        ThemeByList.list[i].filterT = ' (' + _self.filterVoice(k.filter) + ')'
      })
      _self.setData({ ThemeByList: ThemeByList });
      
    };
  },
})


var result = [{
  "theme": {
    "id": 1,
    "title": "我要表白",
    "icon": "pictures/2018/1/31/1517378773870.png",
    "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
   
    "textContent":"说出你想对ta的话。比如：曾经有一份真诚的爱情放在我面前！......",
    "sort": 1
  },
  "list": [
    {
      
    } 
  ]
}, {
    "theme": {
      "id": 2,
      "title": "我要吟诗",
      "icon": "pictures/2018/1/31/1517378750103.png",
      "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
      "textContent": "说出你最喜欢的诗歌。比如：当你老了，头发白了.......",
      "sort": 2
    },
    "list": [
      {
       
      }
    ]
  }, {
    "theme": {
      "id": 3,
      "title": "我要吐槽",
      "icon": "pictures/2018/1/31/1517378730150.png",
      "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
  
      "textContent": "说出你想吐槽的事。比如：这实验可太难了.......",
      "sort": 2
    },
    "list": [
      {
        
      }
    ]
  }, {
    "theme": {
      "id": 4,
      "title": "节日祝福",
      "icon": "pictures/2018/1/31/1517390530820.png",
      "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
    
      "textContent": "说出你想对ta说出的祝福。比如：新年快乐×××....",
      "sort": 2
    },
    "list": [
      {
        
      }
      ]
  }]