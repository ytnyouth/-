// src/pages/recorder.js

//获取应用实例
const app = getApp();
const Global = app.Globals, GlobalConfig = app.GlobalConfig;
const plugin = requirePlugin("WechatSI")
const manager = plugin.getRecordRecognitionManager()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Resource: GlobalConfig.Resource,
    Audio: { status: true },
    UserInfo: {},
    Params: {},
    ThemeByList: {},
    isSatrtRecord:'stop',
    RecordTimer: { Time: "点击播放", duration:0},
    currentText: '', 
    RecorderFile:""
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _self = this
    _self.Recorder = wx.getRecorderManager();
    _self.setData({ Params: { themeId: parseInt(options.id), themeTextId: parseInt(options.themeTextId), pageNum: 1, pageSize: 20 } })
    GlobalConfig.setUserLogin(function (res) {
      _self.setData({ UserInfo: res })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var _self = this, params = _self.data.Params
    if (params.themeId) {
      result.forEach(function (d, f) {
        if (d.theme.id == params.themeId) {
          d.theme.textlist = d.theme.textContent.split('|');
          _self.setData({ ThemeByList: d });
        }

      })
    }
  },
  /**
   * 点击录音
   */streamRecord: function () {
    manager.start({
      duration:20000,
      lang: 'zh_CN',
    })
     manager.onRecognize = (res) => {
       console.log("current result", res.result)
    
       let text = res.result
       this.setData({
         currentText: text,
       })  
   
        // 识别结束事件
    
      
        
    }
   },
 huoqu:function(){ 
   var that = this
   plugin.textToSpeech({
    lang: "zh_CN",
    tts: true,
    
    content: that.data.currentText,
    success: (res) => {
      console.log("succ tts", res.filename)
      let text = res.filename
      this.setData({
        qqq: text,
      })
    },


  })
  },
 
 
  RecorderDone: function () {
   
  manager.stop();
   manager.onStop=(res) => { 
      var Audio = { src: res.tempFilePath, duration: res.duration, fileSize: res.fileSize, status: false }
     this.setData({
      www: Audio,
     })  
     console.log("qqq", Audio)

    }
    var that = this
   
    },
    
            
      
    uploadAudioFile: function(){
     
     var Audio = this.data.www;
      wx.setStorage({//存储到本地
        key: "RecorderFile",
        data: Audio
    })
      wx.setStorage({//存储到本地
        key: "biansheng",
        data: this.data.qqq
      })
 ,

   
    wx.navigateTo({ url: '/src/pages/editAudio', })
      console.log("ffqq", Audio)

  }  ,
})




var result = [{
  "theme": {
    "id": 1,
    "title": "我要表白",
    "icon": "pictures/2018/1/31/1517378773870.png",
    "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
 
    "textContent": "您可以在这进行录音，稍后便可以对您的语音进行编辑",
    "sort": 1
  }
}, {
  "theme": {
    "id": 2,
    "title": "我要吟诗",
    "icon": "pictures/2018/1/31/1517378750103.png",
    "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
    
    "textContent": "您可以在这进行录音，稍后便可以对您的语音进行编辑",
    "sort": 2
  }
}, {
  "theme": {
    "id": 3,
    "title": "我要吐槽",
    "icon": "pictures/2018/1/31/1517378730150.png",
    "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",

    "textContent": "您可以在这进行录音，稍后便可以对您的语音进行编辑",
    "sort": 2
  }
}, {
  "theme": {
    "id": 4,
    "title": "节日祝福",
    "icon": "pictures/2018/1/31/1517390530820.png",
    "iconBackgroundImage": "pictures/2018/1/31/1517390557925.png",
 
    "textContent": "您可以在这进行录音，稍后便可以对您的语音进行编辑",
    "sort": 2
  }
}]